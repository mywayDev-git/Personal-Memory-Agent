from pathlib import Path

p=Path('README.md')
s=p.read_text(encoding='utf-8')
start=s.index('## 답변·검증 비교 실험')
end=s.index('Windows PC에서 개인 기록을 저장하고',start)
section=s[start:end]
s=s[:start]+s[end:]
section=section.replace('현재 상태 질문은 원문 기반 답변·검증 경로를 사용합니다.', '**실험 결과 채택 보류이며, 기본 앱은 기존 답변 경로를 유지합니다.** `PMA_ANSWER_VALIDATION=1`을 설정하면 실험 후보를 켤 수 있습니다. 후보에서는 현재 상태 질문을 원문 기반 답변·검증 경로로 전달합니다.')
section=section.replace('--tag final-1','--tag candidate-rerun')
section=section.replace('로컬 Qwen/BGE 서버가 준비된 상태에서 아래 명령을 실행합니다.', '평가 실행기는 후보 옵션을 명시적으로 켭니다. 로컬 Qwen/BGE 서버가 준비된 상태에서 아래 명령을 실행합니다.')
section += '\n최초 평가 결과는 `output/answer-validation-v1/report.html`에 보존했습니다. `final-1` 실행은 당시 코드와 함께 동결되어 있으며, 기본 경로 보호 설정을 추가한 현재 코드로 다시 실행할 때는 새 태그를 사용합니다. 평가기 예외가 발생했던 한 사례의 네 조건은 `harness-retry`로 재실행하고 `replacements.json`에 대체 경로를 기록했습니다. 원래 결과는 삭제하지 않았습니다. 원문 대조 판정은 Codex의 검토이며 독립적인 사람 평가가 아닙니다.\n'
p.write_text(s.rstrip()+'\n\n'+section,encoding='utf-8')
