import ast
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).parent
load = lambda p: json.loads(p.read_text(encoding='utf-8'))
mapping = load(ROOT/'replacements.json')
reviews = load(ROOT/'review.json')
rows = []
by_phase = defaultdict(list)
hashes = defaultdict(set)
for original in sorted((ROOT/'final-1').glob('*/*--*.json')):
    phase = original.parent.name
    if phase == 'prepare':
        continue
    key = original.relative_to(ROOT).as_posix()
    p = ROOT/mapping.get(key, key)
    d = load(p)
    actual = p.relative_to(ROOT).as_posix()
    assert d['status'] == 'complete', actual
    assert reviews[actual]['sha256'] == hashlib.sha256(p.read_bytes()).hexdigest(), actual
    assert sum(t['stage']=='repair_start' for t in d['diagnostics']) <= 1, actual
    for item in d['response'].get('items', []):
        ids = {r['id'] for r in d.get('found', {}).get('results', d['response'].get('results', []))}
        assert set(item['citations']) <= ids, actual
    if phase == 'fixed':
        hashes[d['case']].add(d['evidence_hash'])
        assert sum(c['endpoint']=='completions' for c in d['calls']) <= 4, actual
    row = dict(d, artifact=actual, matrix_artifact=key, adjudication=reviews[actual])
    rows.append(row)
    by_phase[phase].append(row)
assert len(rows) == 436
assert all(len(v)==1 for v in hashes.values())
assert {k:len(v) for k,v in by_phase.items()} == dict(application=70,fixed=280,live=70,repeat=16)
stability=[]
for cid in sorted({r['case'] for r in by_phase['repeat']}):
    group=[r for r in by_phase['fixed'] if r['case']==cid and r['condition']=='repair']
    group += [r for r in by_phase['repeat'] if r['case']==cid]
    assert len(group)==3
    assert len({r['evidence_hash'] for r in group})==1
    answers=[dict(status=r['response']['status'],items=r['response']['items']) for r in group]
    stability.append(dict(case=cid,unique_answers=len({json.dumps(a,sort_keys=True,ensure_ascii=False) for a in answers}),judgments=[r['adjudication']['label'] for r in group],answers=answers))
for phase, values in by_phase.items():
    for condition in {r['condition'] for r in values}:
        selected=[r for r in values if r['condition']==condition]
        (ROOT/f'{phase}-{condition}.jsonl').write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in selected)+'\n',encoding='utf-8')
representative=[]
for cid in ['state-0','state-1','state-2','relative-2','negation-0','negation-1','omission-0','cause-1','cause-2','untrusted-2','distractor-negative','correction-0']:
    selected=[r for r in by_phase['fixed'] if r['case']==cid]
    representative.append(dict(case=cid,conditions=[dict(condition=r['condition'],answer=r['response'],judgment=r['adjudication'],diagnostics=r['diagnostics'],evidence=r.get('found',{}).get('results',[])) for r in selected]))
(ROOT/'representative_cases.json').write_text(json.dumps(representative,ensure_ascii=False,indent=2),encoding='utf-8')
phase_changes=[]
for app in by_phase['application']:
    live=next(r for r in by_phase['live'] if r['case']==app['case'])
    def memories(row):
        return sorted(json.dumps({k:m[k] for k in ['text','reference_time','memory','evidence']},sort_keys=True,ensure_ascii=False) for m in row['memories'])
    phase_changes.append(dict(case=app['case'],extraction_identical=memories(app)==memories(live),application_judgment=app['adjudication']['label'],live_judgment=live['adjudication']['label'],note='Label changes alone do not establish extraction causality: selection IDs and downstream generation also rerun.'))
(ROOT/'extraction_comparison.json').write_text(json.dumps(phase_changes,ensure_ascii=False,indent=2),encoding='utf-8')
def methods(path, cls):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    return {m.name:ast.dump(m,include_attributes=False) for c in tree.body if isinstance(c,ast.ClassDef) and c.name==cls for m in c.body if isinstance(m,ast.FunctionDef)}
old=methods(ROOT/'baseline-code/pma/models.py','LocalModels')
new=methods(Path('pma/models.py'),'LocalModels')
legacy=methods(Path('pma/legacy_answer.py'),'LegacyAnswerMethods')
unchanged={name:old[name]==new[name] for name in ['extract','embed','understand','select','compact_evidence']}
legacy_same={name:old[name]==legacy[name] for name in ['answer','verify']}
assert all(unchanged.values()) and all(legacy_same.values())
protected=['pma/facts.py','pma/store.py','schema/memory_extraction.schema.json','schema/memory_extraction_output.schema.json']
file_same={name:Path(name).read_bytes()==(ROOT/'baseline-code'/name).read_bytes() for name in protected}
assert all(file_same.values())
audit=dict(matrix_counts={k:len(v) for k,v in by_phase.items()},total=len(rows),all_review_hashes_valid=True,identical_fixed_evidence_cases=len(hashes),maximum_one_repair=True,unchanged_methods=unchanged,legacy_methods_identical=legacy_same,unchanged_files=file_same,repeated_cases=stability,semantic_stable_cases=sum(len(set(s['judgments']))==1 for s in stability),exact_stable_cases=sum(s['unique_answers']==1 for s in stability),harness_failures_replaced=2,replacements=mapping,production_default='legacy; PMA_ANSWER_VALIDATION=1 enables experimental candidate',limitations=['Judgments are Codex source comparisons, not independent human annotations.','Small synthetic corpus; not a population accuracy estimate.','Holdout has six cases; no post-holdout prompt tuning.'])
(ROOT/'final_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in audit.items() if k not in ['repeated_cases','replacements']},ensure_ascii=False,indent=2))
