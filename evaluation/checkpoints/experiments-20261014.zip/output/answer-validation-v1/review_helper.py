import json,hashlib,sys
from pathlib import Path
ROOT=Path(__file__).parent
REV=ROOT/'semantic_review.json'

def signature(d):
 response=d.get('response',{})
 sources={r['id']:r for r in d.get('found',{}).get('results',response.get('results',[]))}
 items=[]
 for item in response.get('items',[]):
  quotes=[]
  for cid in item['citations']:
   row=sources.get(cid)
   quotes.extend(e['quote'] for e in row.get('evidence',[])) if row else quotes.append('[INVALID CITATION]')
  items.append(dict(text=item['text'],quotes=quotes))
 value=dict(case=d['case'],status=response.get('status'),items=items)
 provenance=[]
 for item in response.get('items',[]):
  provenance.append([{k:sources[c].get(k) for k in ['source_text','evidence','time']} if c in sources else {'invalid':c} for c in item['citations']])
 return hashlib.sha256(json.dumps(dict(answer=value,provenance=provenance),ensure_ascii=False,sort_keys=True).encode()).hexdigest(),value

def collect():
 mapping_path=ROOT/'replacements.json'
 mapping=json.loads(mapping_path.read_text(encoding='utf-8')) if mapping_path.exists() else {}
 result=[]
 for original in sorted((ROOT/'final-1').glob('*/*--*.json')):
  if original.parent.name=='prepare':continue
  key=str(original.relative_to(ROOT)).replace(chr(92),'/')
  p=ROOT/mapping.get(key,key)
  result.append((p,json.loads(p.read_text(encoding='utf-8'))))
 return result

review=json.loads(REV.read_text(encoding='utf-8')) if REV.exists() else {}
mode=sys.argv[1] if len(sys.argv)>1 else 'list'
if mode=='list':
 seen=set();start=int(sys.argv[2]) if len(sys.argv)>2 else 0;limit=int(sys.argv[3]) if len(sys.argv)>3 else 20
 rows=[]
 for p,d in collect():
  key,value=signature(d)
  if key in review or key in seen:continue
  seen.add(key);rows.append((key,value,p))
 for key,value,p in rows[start:start+limit]:
  print(key[:12],p.parent.name,p.name,json.dumps(value,ensure_ascii=False))
 print('UNREVIEWED UNIQUE',len(rows))
elif mode=='assign':
 additions=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
 signatures={signature(d)[0] for p,d in collect()}
 for prefix,decision in additions.items():
  matches=[k for k in signatures if k.startswith(prefix)]
  if len(matches)!=1:raise ValueError((prefix,len(matches)))
  review[matches[0]]=dict(label=decision[0],reason=decision[1],reviewer='Codex 원문 대조; 독립된 사람 평가 아님')
 REV.write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
elif mode=='export':
 out={}
 for p,d in collect():
  key,value=signature(d)
  if key in review:
   out[str(p.relative_to(ROOT)).replace(chr(92),'/')]=dict(review[key],sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 (ROOT/'review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
 print('reviewed',len(out),'of',len(collect()))
