from pathlib import Path
root=Path(__file__).parent
baseline=(root/'baseline-code/pma/models.py').read_text(encoding='utf-8')
answer=baseline[baseline.index('    def answer('):baseline.index('    def select(')]
verify=baseline[baseline.index('    def verify('):baseline.index('    @staticmethod\n    def compact_evidence')]
Path('pma/legacy_answer.py').write_text('"""Preserved baseline answer policy while the experimental policy is unaccepted."""\n\nfrom copy import deepcopy\n\nfrom .models import ANSWER_SCHEMA\n\n\nclass LegacyAnswerMethods:\n'+answer+verify,encoding='utf-8')
p=Path('pma/models.py');s=p.read_text(encoding='utf-8')
s=s.replace('    def answer(self, question, evidence, *, feedback=None):\n', '    def answer(self, question, evidence, *, feedback=None):\n        if not self.settings.answer_validation:\n            from .legacy_answer import LegacyAnswerMethods\n\n            return LegacyAnswerMethods.answer(self, question, evidence)\n')
s=s.replace('        """Boolean compatibility interface for existing diagnostic callers."""\n', '        """Boolean compatibility interface for existing diagnostic callers."""\n        if not self.settings.answer_validation:\n            from .legacy_answer import LegacyAnswerMethods\n\n            return LegacyAnswerMethods.verify(self, question, evidence, items)\n')
p.write_text(s,encoding='utf-8')
p=Path('pma/settings.py');s=p.read_text(encoding='utf-8').replace('    context_tokens: int = 16384','    answer_validation: bool = False\n    context_tokens: int = 16384').replace('            context_tokens=int(', '            answer_validation=os.getenv("PMA_ANSWER_VALIDATION", "0") == "1",\n            context_tokens=int(');p.write_text(s,encoding='utf-8')
p=Path('pma/service.py');s=p.read_text(encoding='utf-8').replace('            if hasattr(self.models, "review"):', '            if hasattr(self.models, "review") and self.settings.answer_validation:');p.write_text(s,encoding='utf-8')
p=Path('pma/grounding.py');s=p.read_text(encoding='utf-8').replace('def grounded_response(found):','def grounded_response(found, *, semantic_current=False):').replace('    if kind in {"why", "current"}:','    if kind == "why" or (kind == "current" and semantic_current):');p.write_text(s,encoding='utf-8')
p=Path('pma/answer_review.py');s=p.read_text(encoding='utf-8').replace('response = grounded_response(found)','response = grounded_response(found, semantic_current=True)');p.write_text(s,encoding='utf-8')
p=Path('evaluation/answer_validation.py');s=p.read_text(encoding='utf-8').replace('        embedding_revision=prior[', '        answer_validation=True,\n        embedding_revision=prior[').replace('old_grounded if label == "baseline" else grounded_response,','old_grounded if label == "baseline" else lambda f: grounded_response(f, semantic_current=True),').replace('settings=dict(llm=vars(settings.llm), embedding=settings.embedding_key)', 'settings=dict(llm=vars(settings.llm), embedding=settings.embedding_key, answer_validation=settings.answer_validation)');p.write_text(s,encoding='utf-8')
print('Experimental policy retained, production default restored. Reruns require a new tag.')
