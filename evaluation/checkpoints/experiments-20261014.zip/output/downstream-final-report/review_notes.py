"""Explicit source/answer adjudication by the coding agent, not an automatic judge.
The pre-existing cases.json remains the gold specification. Ambiguous results
are not credited. Re-run only after reviewing the actual saved responses.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).parent
PATHS = {
    'before': Path('output/downstream-before-v1'),
    'after': Path('output/downstream-final-v8-frozen'),
    'live': Path('output/downstream-final-v8-live'),
    'distractors': Path('output/downstream-final-v8-distractors'),
}
path = ROOT / 'review.json'
review = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
review['reviewer'] = 'Codex 원문·실제 답변 대조. 독립된 사람의 검토는 아님.'
review['policy'] = '명시된 질문에 답하고 원문 밖 주장을 하지 않아야 정답. 알 수 없는 값의 적절한 보류는 별도 집계. 답변 상태와 의미 판정은 별개. correction-2 제외. 경계 사례는 성공으로 계산하지 않음.'

ISSUES = {
    'negation-1': '고정 추출이 결정을 하지 않음과 부정하기로 한 결정을 혼동함. 저장 원문과 추출은 그대로 유지됨.',
    'omission-0': '고정 추출이 생략된 행위자를 self로 지정함.',
    'omission-2': '고정 추출이 생략된 행위자를 민수로 확정하고 서술어를 줄다로 추출함.',
    'relative-2': '고정 추출·정규화에 인용된 발화 시점 기준의 사건 날짜가 정확히 표현되지 않음.',
    'emotion-2': '별도의 슬픔 기억이 누락됨. 답변은 원문 인용에서 복구한 것이며 추출 자체 개선은 아님.',
    'untrusted-2': '명령 발화를 책을 줬다고 대답한 것으로 요약함.',
}

def label(arm, cid, judgment, note='', issue=None):
    entry = json.loads((PATHS[arm] / f'{cid}.json').read_text(encoding='utf-8'))
    review.setdefault(arm, {})[cid] = dict(
        judgment=judgment, note=note,
        extraction_issue=ISSUES.get(cid, '') if issue is None else issue,
        response_sha256=hashlib.sha256(json.dumps(entry.get('response', {}), ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
    )

cases = json.loads((PATHS['before'] / 'cases.json').read_text(encoding='utf-8'))
for c in cases:
    label('before', c['id'], 'over_abstention', '근거가 있으나 답변하지 않거나 현재 상태를 충분히 설명하지 못함.')
for cid in ['plan-1', 'quote-0', 'headers-0', 'headers-1', 'headers-2']:
    label('before', cid, 'correct')
for cid in ['omission-0', 'omission-2', 'relative-1', 'cause-1', 'cause-2', 'state-2']:
    label('before', cid, 'appropriate_abstention', '미확정 값 또는 실행을 단정하지 않음. 잘못된 필터로 우연히 보류한 사례도 포함.')
for cid in ['quote-2', 'untrusted-2']:
    label('before', cid, 'incorrect', '발화 내용을 실제 전달 행위로 바꾸거나 발화자를 전달 행위자로 확정함.')
label('before', 'correction-2', 'excluded', '동일 사건 여부가 불명확하여 모순 평가에서 제외.')

for c in cases:
    label('after', c['id'], 'correct')
for cid in ['quote-2', 'omission-0', 'omission-2', 'relative-1', 'cause-1', 'cause-2']:
    label('after', cid, 'appropriate_abstention', '원문으로 확정할 수 없는 인물·날짜·원인을 확정하지 않음.')
for cid in ['relative-2', 'state-0', 'state-1', 'state-2', 'untrusted-2']:
    label('after', cid, 'over_abstention', '질문에 필요한 설명을 완성하지 못함. 인용 날짜·현재 상태 또는 실제 실행 여부의 해석/검증이 남음.')
label('after', 'untrusted-2', 'over_abstention', '행동으로 확정하는 오류는 막았지만 명령 발화만 반복하고 실제 전달 여부는 미확인이라고 명시하지 않음.')
label('after', 'negation-1', 'needs_review', '원문 인용은 정확하나 결정을 하지 않았다는 말을 계획이 없다는 말로 일반화함. 성공으로 계산하지 않음.')
label('after', 'correction-0', 'incorrect', '정정된 7일 대신 6일을 답함. 자동 정정 연결은 이번 구현 범위 밖이며 해결로 계산하지 않음.')
label('after', 'correction-1', 'incorrect', '고정 정답은 추가 사건인 6일과 7일 보존인데 7일만 답함. 최종 기록이라는 질문 표현의 해석 문제도 후속 검토 필요.')
label('after', 'correction-2', 'excluded', '동일 사건 여부가 불명확하여 모순 평가에서 제외.')

for c in json.loads((PATHS['distractors'] / 'cases.json').read_text(encoding='utf-8')):
    label('distractors', c['id'], 'correct', issue='')
label('distractors', 'distractor-negative', 'over_abstention', '올바른 부정 답변 후보를 검증기가 반대로 읽고 거절함. 성공으로 계산하지 않음.', '')
for cid in ['distractor-quote', 'distractor-adjacent']:
    label('distractors', cid, 'appropriate_abstention', '청자 또는 원인의 근거가 없어 보류함.', '')
label('distractors', 'distractor-cancel', 'correct', '취소와 반대 방향의 전달을 구별함. 불필요한 반대 방향 기록도 덧붙이는 문제는 남음.', '')

# Fresh extraction outputs were separately inspected. Their semantic judgments
# match the frozen run; the repeated-visit failure chooses a different date.
for cid, item in review['after'].items():
    label('live', cid, item['judgment'], item['note'], item['extraction_issue'])
label('live', 'correction-1', 'incorrect', '고정 정답은 6일과 7일 모두인데 새 추출 실행에서는 6일만 답함. 고정 추출 실행은 7일만 답했음.', '')

review['findings'] = [
    '고정 추출 비교: 정답 5→21, 적절한 보류 6→6, 오답 2→2, 과도한 보류 22→5. 수정 후 1건은 경계 사례로 검토 대기. 정답 또는 적절한 보류 인정은 11/35→27/35이며 일반화 정확도가 아니다.',
    '이전 오답이었던 청자 불명 인용과 명령을 실제 행동으로 확정하는 문제는 줄었다. 현재 오답 2건은 정정 날짜와 추가 방문 날짜 선택이다. 추출 결과 자체는 변경하지 않았다.',
    '새로 추출한 36개도 별도 실행했다. 원래 잘못 추출된 생략 주체, 부정 결정, 감정 누락 등은 여전히 남아 있으며 후처리 성공으로 계산하지 않는다.',
    '방해 기록 8개 중 7개는 정답 또는 적절한 보류였다. 부정 질문 1개는 검증기가 올바른 부정 답변을 잘못 거절했다. 반대 방향의 기록을 불필요하게 덧붙이는 문제도 남았다.',
    '고정 추출 비교의 생성 호출은 39→92, 생성 토큰은 8,888→65,840, 사례별 중앙 시간은 0.74→5.18초, p95는 2.22→8.22초다. 수정 전에는 잘못된 필터로 답변 단계에 도달하지 않는 경우가 많았다는 차이를 고려해야 한다.',
    '따라서 전체 완료 기준을 충족했다고 볼 수 없다. 특히 기존의 취소 상태 설명이 이번 실행에서는 보류된 회귀도 남았다. 기본 앱에 Kiwi나 새 사건 그래프를 추가하지 않았으며 개인 DB는 변경하지 않았다.',
    '이번 비교는 반복 개발에 사용한 회귀 사례다. temperature=0·seed=42여도 임시 DB의 UUID와 기록 시각 등 프롬프트에 들어가는 부가 값은 실행마다 달라질 수 있다. 단일 실행 수치를 안정성이나 독립 평가 성능으로 해석하지 않는다.',
    '12개 정보 손실 진단: selected와 all_memories의 의미 결과가 같은 경우가 많았다. 이 작은 표본에서는 단순히 전체 기억을 전달하는 것이 뚜렷한 개선을 만들지 않았다. 큰 개인 DB의 검색 성능을 뜻하지 않는다.',
    '인용 날짜 relative-2는 전체 원문에서 10월9일을 맞혔지만, 기억·근거 조건에서는 기록 기준 10월13일과 발화일 10월10일을 섞어 모순된 설명을 만들고 검증에서 거절됐다. 시간 정보의 전달 형식과 발화/사건의 기준 시각 분리를 먼저 시험할 근거다.',
    '원문 전체가 항상 안전한 대안은 아니다. cause-1에서는 비가 왔다는 문장과 집에 갔다는 문장을 인과관계로 만들고 검증도 통과했다. 반면 선택된 기억 조건은 보류했고 전체 기억 조건은 원인이 명시되지 않았다고 답했다.',
    '다음 단계는 큰 그래프나 전면 재추출보다 시간 기준의 명시적 구분, 검증기의 부정·인용 오류, 정정/반복 사건 선택의 소규모 분리 실험을 권한다. 근거 없는 자동 확정을 줄이는 보호 규칙은 유지하고, 모델 검증 true만으로 의미 정답이라 판단하지 않는다.',
]

review['diagnostic'] = {}
for file in sorted(Path('output/downstream-final-v8-diagnostic').glob('*.json')):
    entry = json.loads(file.read_text(encoding='utf-8'))
    if not isinstance(entry, dict) or 'case' not in entry:
        continue
    cid = entry['case']
    labels = dict(selected='correct', all_memories='correct', source='correct')
    note = '세 조건을 같은 질문·답변 프롬프트로 대조함.'
    if cid == 'negation-1':
        labels.update(selected='needs_review', all_memories='needs_review')
        note = '기억 조건은 계획 부재로 일반화했고 원문 조건은 원문을 정확히 인용했다.'
    elif cid == 'quote-2':
        labels.update(selected='appropriate_abstention', all_memories='appropriate_abstention', source='incorrect')
        note = '원문 조건은 수신자 지연을 행위자로 바꾸었으나 검증에서 거절했다.'
    elif cid == 'relative-0':
        labels['source'] = 'over_abstention'
        note = '원문 조건은 어제라는 표현만 반복하여 요구된 날짜를 정규화하지 않았다.'
    elif cid == 'relative-2':
        labels.update(selected='incorrect', all_memories='incorrect')
        note = '기억 조건의 날짜 설명은 서로 모순되어 검증에서 거절됨. 원문 조건은 10월9일을 맞힘.'
    elif cid == 'cause-1':
        labels.update(selected='appropriate_abstention', all_memories='appropriate_abstention', source='incorrect')
        note = '원문 조건만 없는 인과관계를 만들었고 모델 검증도 통과함.'
    elif cid == 'untrusted-2':
        labels = {k: 'over_abstention' for k in labels}
        note = '세 조건 모두 명령 발화를 반복했다. 실제 실행 여부는 미확인이라는 답을 완성하지 못함.'
    elif cid == 'emotion-2':
        note = '독립 감정 기억은 없지만 원문 근거에 슬픔이 남아 있어 세 조건 모두 답함. 추출 오류 해결은 아님.'
    conditions = {}
    for condition, raw in entry['conditions'].items():
        effective = labels[condition]
        if raw['verified'] is False or not raw['citation_valid']:
            effective = 'appropriate_abstention' if cid == 'quote-2' else 'over_abstention'
        conditions[condition] = dict(raw_judgment=labels[condition], effective_judgment=effective,
                                     response_sha256=hashlib.sha256(json.dumps(raw,ensure_ascii=False,sort_keys=True).encode()).hexdigest())
    review['diagnostic'][cid] = dict(judgment='diagnostic_only', note=note, conditions=conditions)

path.write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding='utf-8')
