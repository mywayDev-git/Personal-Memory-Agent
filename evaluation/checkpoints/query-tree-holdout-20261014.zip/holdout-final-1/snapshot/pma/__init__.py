"""Local personal memory application."""
